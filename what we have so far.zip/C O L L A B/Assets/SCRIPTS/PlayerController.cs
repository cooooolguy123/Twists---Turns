﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	public float moveSpeed = 20f;
	float velX;
	float velY;
	Rigidbody2D rigBody;

	// Use this for initialization
	void Start () {
		rigBody = GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void Update () {
		velX = Input.GetAxisRaw ("Horizontal");
		velY = Input.GetAxisRaw ("Vertical");
		rigBody.velocity = new Vector2 (velX * moveSpeed, velY * moveSpeed);
	}
}
